import sys
import ast
import mylib
import doctest

def main():
    """
    Programa principal que ejecuta funciones de mylib según argumentos recibidos.
    
    Uso:
    python main.py <nombre_funcion> <parametros>

    Para correr los tests:
    python main.py --test

    Ejemplo:
    python main.py ponerTapones [10,20] [20,10]
    python main.py trasponer_divide_venceras [[1,2],[3,4]]
    """

    if '--test' in sys.argv:
        doctest.testmod(mylib, verbose=True)
        return

    if len(sys.argv) < 3:
        print("Uso: python main.py <funcion> <parametros...>")
        print("Ejemplo:")
        print("  python main.py trasponer_divide_venceras [[1,2],[3,4]]")
        print("  python main.py ponerTapones [10,20] [20,10]")
        return

    nombre_funcion = sys.argv[1]
    try:
        # Intenta evaluar los argumentos como listas, números, etc.
        parametros = [ast.literal_eval(arg) for arg in sys.argv[2:]]
    except Exception as e:
        print("Error al interpretar los argumentos:", e)
        return

    if hasattr(mylib, nombre_funcion):
        funcion = getattr(mylib, nombre_funcion)
        try:
            resultado = funcion(*parametros)
            print(f"{nombre_funcion}({', '.join(map(str, parametros))}) = {resultado}")
        except Exception as e:
            print(f"Error al ejecutar {nombre_funcion}: {e}")
    else:
        print(f"La función '{nombre_funcion}' no está definida en mylib.")

if __name__ == "__main__":
    main()

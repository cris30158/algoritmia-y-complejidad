

#PL1


#ejercicio 5
def esprimo(n):
    """
    Determina si un número es primo.

    >>> esprimo(2)
    True
    >>> esprimo(3)
    True
    >>> esprimo(4)
    False
    >>> esprimo(5)
    True
    >>> esprimo(11)
    True
    >>> esprimo(15)
    False
    >>> esprimo(1)
    False
    >>> esprimo(0)
    False
    >>> esprimo(-7)
    False
    """
    esprimo=True
    if (n<2): 
        esprimo=False
    else:
        for i in range(2,int(n**0.5)+1): #2....(raiz de n)
            if (n%i)==0: esprimo=False
    return esprimo


#ejercicio 9
def sumatorio(n):
    """
    Calcula el sumatorio de un número entero positivo n.
    
    >>> sumatorio(0)
    0
    >>> sumatorio(1)
    1
    >>> sumatorio(2)
    3
    >>> sumatorio(3)
    6
    >>> sumatorio(5)
    15
    >>> sumatorio(10)
    55
    >>> sumatorio(-5)
    Traceback (most recent call last):
        ...
    ValueError: El número debe ser un entero no negativo
    """
     
    if n < 0:
        raise ValueError("El número debe ser un entero no negativo") # Manejo de error para negativos
    elif n == 0:
        return 0
    else:
        return n + sumatorio(n - 1)
    

    

if __name__ == "__main__":
    import doctest
    doctest.testmod( verbose=True)


#PL2


#ejercicio 2

def obtener_razon(fichero):
    """
    Calcula la razón longitud/peticiones de un fichero.
    Parámetros:
        fichero: Tupla (longitud, peticiones)
    Devuelve:
        Razón longitud/peticiones
    """
    longitud, peticiones = fichero
    return longitud / peticiones


def algVoraz(fichero_original):
    """
    Calcula el tiempo medio de carga para el orden dado.
    
    >>> algVoraz([(30, 5), (20, 2), (10, 10), (40, 1)])
    [(10, 10), (30, 5), (20, 2), (40, 1)]
    520
    28.8889

    >>> algVoraz([(8,2), (2,1), (5,8), (9,20), (1,18), (3,1)])
    [(1, 18), (9, 20), (5, 8), (2, 1), (3, 1), (8, 2)]
    431
    8.62

    >>> algVoraz([(100, 50), (200, 100), (50, 25)])
    [(100, 50), (200, 100), (50, 25)]
    43750
    250.0

    >>> algVoraz([(5, 5), (10, 10), (20, 20), (40, 40)])
    [(5, 5), (10, 10), (20, 20), (40, 40)]
    3875
    51.6667

    >>> algVoraz([])
    0.0
    
    Parámetros:
        -ficheros_ordenados: Lista ordenada de tuplas (longitud, peticiones)
    Devuelve:
        -Tiempo medio de carga
    """
    if not fichero_original: # Para evitar error de 0/0 con listas vacias
        return 0.0
    
    ficheros=sorted(fichero_original, key=obtener_razon)
    print(ficheros)
    lenlista=len(ficheros)
    texe=0
    sumalx=0
    sumapx=0
    for i in range (lenlista): #Recorrer la lista por su longitud, de i=0 a i=lenlista-1
        sumalx+=ficheros[i][0]
        texe+=sumalx*ficheros[i][1]
        sumapx+=ficheros[i][1]

    print(texe)
    # Solución redondeada con 4 decimales para que sea más sencillo de probar
    return round(texe/sumapx,4)

##########################################################################################################################

#ejercicio 4
def prim(graph):
    """
    Implementación del algoritmo de Prim utilizando una matriz de adyacencia 
    
    graph: Matriz de adyacencia (lista de listas) representando el grafo (comienza desde el nodo 0)
    return: Lista de aristas del Árbol de Expansión Mínima (MST).

    >>> graph = [
    ...     [0, 2, 0, 6, 0],
    ...     [2, 0, 3, 8, 5],
    ...     [0, 3, 0, 0, 7],
    ...     [6, 8, 0, 0, 9],
    ...     [0, 5, 7, 9, 0]
    ... ]
    >>> prim(graph)
    [(0, 1, 2), (1, 2, 3), (1, 4, 5), (0, 3, 6)]

    # Grafo diferente con conexiones distintas
    >>> graph2 = [
    ...     [0, 1, 4, 0, 0],
    ...     [1, 0, 2, 6, 0],
    ...     [4, 2, 0, 3, 5],
    ...     [0, 6, 3, 0, 7],
    ...     [0, 0, 5, 7, 0]
    ... ]
    >>> prim(graph2)
    [(0, 1, 1), (1, 2, 2), (2, 3, 3), (2, 4, 5)]

    # Grafo completamente conectado con pesos distintos
    >>> graph3 = [
    ...     [0, 10, 20, 30, 40],
    ...     [10, 0, 50, 60, 70],
    ...     [20, 50, 0, 80, 90],
    ...     [30, 60, 80, 0, 100],
    ...     [40, 70, 90, 100, 0]
    ... ]
    >>> prim(graph3)
    [(0, 1, 10), (0, 2, 20), (0, 3, 30), (0, 4, 40)]

    # Grafo con pesos iguales
    >>> graph4 = [
    ...     [0, 5, 5, 5, 5],
    ...     [5, 0, 5, 5, 5],
    ...     [5, 5, 0, 5, 5],
    ...     [5, 5, 5, 0, 5],
    ...     [5, 5, 5, 5, 0]
    ... ]
    >>> prim(graph4)
    [(0, 1, 5), (0, 2, 5), (0, 3, 5), (0, 4, 5)]

    # Grafo que ya es un MST (una línea)
    >>> graph5 = [
    ...     [0, 1, 0, 0, 0],
    ...     [1, 0, 2, 0, 0],
    ...     [0, 2, 0, 3, 0],
    ...     [0, 0, 3, 0, 4],
    ...     [0, 0, 0, 4, 0]
    ... ]
    >>> prim(graph5)
    [(0, 1, 1), (1, 2, 2), (2, 3, 3), (3, 4, 4)]

    # Grafo vacío
    >>> graph6 = []
    >>> prim(graph6)
    []

    # Grafo con solo un elemento
    >>> graph7 = [0]
    >>> prim(graph7)
    []


    """
    num_nodos = len(graph)  # Número de nodos en el grafo

    if num_nodos < 2: # Si es un grafo vacío o sólo hay un elemento, devuelve una lista vacía
        return []

    nodos_insertados = [False] * num_nodos  #Lista para marcar qué nodos han sido agregados al MST (True si ya está en el MST, False si no).
    aristas_insertadas = []  #  Lista donde guardaremos las aristas seleccionadas en el MST.
    
    dist = [float('inf')] * num_nodos  # Distancia mínima de cada nodo al MST
    parent = [-1] * num_nodos  # Para almacenar la conexión en el MST

    # Inicializamos el primer nodo en el MST
    dist[0] = 0  

    for i in range(num_nodos):
        # Buscar el nodo de menor distancia que aún no está en el MST
        min_dist = float('inf') #crea una lista llamada dist de tamaño num_nodos, donde cada posición se inicializa a infinito.
        u = -1
        for v in range(num_nodos):
            if not nodos_insertados[v] and dist[v] < min_dist:
                min_dist = dist[v]
                u = v

        if u == -1:
            break  # Si no encontramos un nodo válido, terminamos

        # Agregar el nodo al MST
        nodos_insertados[u] = True
        if parent[u] != -1:  # No agregamos la raíz inicial
            aristas_insertadas.append((parent[u], u, graph[parent[u]][u]))

        # Actualizar distancias de los vecinos de u
        for v in range(num_nodos):
            if not nodos_insertados[v] and 0 < graph[u][v] < dist[v]:
                dist[v] = graph[u][v]
                parent[v] = u  # Guardar la arista en el MST

    return aristas_insertadas

##########################################################################################################################

#ejercicio 6

#Versión 1:

def min_pistas(reservas):
    """
    Calcula el número mínimo de pistas necesarias para alojar todas las reservas sin solapamientos.


    >>> min_pistas([(10, 12), (9, 11), (11, 13), (15, 16)])
    [(9, 11), (10, 12), (11, 13), (15, 16)]
    Pista 1: [(9, 11), (11, 13), (15, 16)]
    Pista 2: [(10, 12)]
    2

    >>> min_pistas([(9, 10), (10, 11), (11, 12)])
    [(9, 10), (10, 11), (11, 12)]
    Pista 1: [(9, 10), (10, 11), (11, 12)]
    1

    >>> min_pistas([(9, 12), (10, 13), (11, 14), (12, 15)])
    [(9, 12), (10, 13), (11, 14), (12, 15)]
    Pista 1: [(9, 12), (12, 15)]
    Pista 2: [(10, 13)]
    Pista 3: [(11, 14)]
    3

    >>> min_pistas([(9, 12), (10, 11), (11, 14), (12, 13), (13, 15), (14, 16)])
    [(9, 12), (10, 11), (11, 14), (12, 13), (13, 15), (14, 16)]
    Pista 1: [(9, 12), (12, 13), (13, 15)]
    Pista 2: [(10, 11), (11, 14), (14, 16)]
    2

    >>> min_pistas([])
    []
    0
    """
    # Ordenamos las reservas por hora de inicio
    reservas.sort()
    print(reservas)
   
    # Lista para almacenar las horas de finalización de las reservas en cada pista
    pistas = []
   
    # Diccionario para almacenar las reservas asignadas a cada pista
    asignaciones = {} # por ejemplo, quedaría algo como {0: [(9, 11), (11, 13)], 1: [(10, 12)]}
   
    for inicio, fin in reservas: # Iteramos por todas las reservas
        asignado = False
       
        # Intentamos asignar la reserva a una pista ya existente
        for i in range(len(pistas)):
            if pistas[i] <= inicio:  # Se puede reutilizar la pista si está libre antes de la nueva reserva
                pistas[i] = fin # Sustituimos el valor de fin de la pista donde se podía añadir la reserva por el valor de fin de la misma
                asignaciones[i].append((inicio, fin)) # Añadimos una nueva tupla al diccionario para marcar una nueva reserva en la pista donde se añadió
                asignado = True
                break # Reserva ya añadida, salimos del bucle
       
        # Si no se pudo asignar a una pista existente, añadimos una nueva
        if not asignado:
            pistas.append(fin)
            asignaciones[len(pistas) - 1] = [(inicio, fin)] # Añadimos un nuevo valor del diccionario para la pista nueva con su primera reserva


    # Mostrar las pistas con sus reservas
    for pista, reservas in asignaciones.items(): # Asignaciones.items() para iterar sobre las claves y valores del diccionario
        print(f"Pista {pista + 1}: {reservas}")
   
    # El número de pistas utilizadas es el tamaño de la lista
    return len(pistas)



#Versión 2:

# Función para ordenar: primero por hora, luego por tipo (-1 antes que 1)
def ordenar_eventos(evento):
    hora, tipo = evento
    return (hora, tipo)  # como tipo es -1 o +1, -1 se ordena antes si hay empate
    
def opcion2(reservas):
    """
    Calcula el número mínimo de pistas necesarias para alojar todas las reservas sin solapamientos.

    >>> opcion2([(10, 12), (9, 11), (11, 13), (15, 16)])
    2

    >>> opcion2([(9, 10), (10, 11), (11, 12)])
    1

    >>> opcion2([(9, 12), (10, 13), (11, 14), (12, 15)])
    3

    >>> opcion2([(9, 12), (10, 11), (11, 14), (12, 13), (13, 15), (14, 16)])
    2

    >>> opcion2([])
    0
    """
    if not reservas: return 0
    
    lista = []
    for inicio, fin in reservas:
        lista.append((inicio, 1))   # +1 por inicio
        lista.append((fin, -1))     # -1 por fin

    lista.sort(key=ordenar_eventos)

    ocupadas = 0 #pistas ocupadas actualmente
    max_pistas = 0  #número máximo de "ocupadas" a la vez

    for hora, tipo in lista:
        ocupadas += tipo #sumo o resto uno a las pistas ocupadas
        if ocupadas > max_pistas: #compruebo si el valor actual es el máximo de momento
            max_pistas = ocupadas

    return max_pistas #el máximo número de pistas encontrado será el número mínimo de pistas totales necesarias






if __name__ == "__main__":
    import doctest
    doctest.testmod( verbose=True)
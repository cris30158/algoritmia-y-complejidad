import sys
import ast
import mylib
import doctest

def main():
    """
    Programa principal que ejecuta funciones de mylib según argumentos recibidos.

    Uso:
    python main.py <nombre_funcion> <parametros>

    Para correr los tests:
    python main.py --test

    Ejemplos:
    python main.py algVoraz "[(30, 5), (20, 2), (10, 10), (40, 1)]"
    python main.py prim "[[0, 2, 0, 6, 0], [2, 0, 3, 8, 5], [0, 3, 0, 0, 7], [6, 8, 0, 0, 9], [0, 5, 7, 9, 0]]"
    python main.py min_pistas "[(10, 12), (9, 11), (11, 13), (15, 16)]"
    python main.py opcion2 "[(10, 12), (9, 11), (11, 13), (15, 16)]"
    """
    if '--test' in sys.argv:
        doctest.testmod(mylib, verbose=True)
        return

    if len(sys.argv) < 3:
        print("Uso: python main.py <funcion> <parametros>")
        print("Ejemplos:")
        print("  python main.py algVoraz \"[(30, 5), (20, 2)]\"")
        print("  python main.py prim \"[[0, 1], [1, 0]]\"")
        return

    nombre_funcion = sys.argv[1]

    try:
        parametros = [ast.literal_eval(arg) for arg in sys.argv[2:]]
    except Exception as e:
        print("Error al interpretar los argumentos:", e)
        return

    if hasattr(mylib, nombre_funcion):
        funcion = getattr(mylib, nombre_funcion)
        try:
            resultado = funcion(*parametros)
            print(f"{nombre_funcion}({', '.join(map(str, parametros))}) = {resultado}")
        except Exception as e:
            print(f"Error al ejecutar {nombre_funcion}: {e}")
    else:
        print(f"La función '{nombre_funcion}' no está definida en mylib.")

if __name__ == "__main__":
    main()

